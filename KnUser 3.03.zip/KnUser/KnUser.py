import os
import time
import socket
import asyncio
import random
import sys
import wikipedia
from pyrogram import Client, filters
from pyrogram.errors import FloodWait
from colorama import Fore, Style
from art import text2art
import importlib.util

# Определите папку для сессий
session_folder = "sessions"

app = Client("KnUser")

# Создаем директорию для сессий, если ее нет
if not os.path.exists(session_folder):
    os.makedirs(session_folder)

# Проверяем наличие файлов сессии и config.txt
if not os.path.exists(os.path.join(session_folder, "KnUser.session")):
    print(f"{Fore.WHITE}[{time.strftime('%d-%m-%Y %H:%M:%S')}]> {Fore.YELLOW}Файлы сессии не найдены")
    time.sleep(1.5)
    print(f"{Fore.WHITE}[{time.strftime('%d-%m-%Y %H:%M:%S')}]> {Fore.GREEN}Начнем первоначальную настройку")
    time.sleep(1.5)
    
    api_id = input(f"{Fore.WHITE}[{time.strftime('%d-%m-%Y %H:%M:%S')}]> {Fore.GREEN}Введите API ID: ")
    time.sleep(1.5)
    api_hash = input(f"{Fore.WHITE}[{time.strftime('%d-%m-%Y %H:%M:%S')}]> {Fore.GREEN}Введите API Hash: ")
    time.sleep(1.5)
    phone_number = input(f"{Fore.WHITE}[{time.strftime('%d-%m-%Y %H:%M:%S')}]> {Fore.GREEN}Введите номер телефона, привязанный в Телеграмм: ")
    time.sleep(1.5)

    app = Client(
        os.path.join(session_folder, "KnUser"),
        api_id=api_id,
        api_hash=api_hash,
        phone_number=phone_number
    )

    # Сохраняем API ID и API Hash в конфигурационный файл
    with open(os.path.join(session_folder, "config.txt"), "w") as config_file:
        config_file.write(f"API_ID: {api_id}\n")
        config_file.write(f"API_HASH: {api_hash}\n")
else:
    # Загружаем API ID и API Hash из файла конфигурации
    with open(os.path.join(session_folder, "config.txt"), "r") as config_file:
        for line in config_file:
            if line.startswith("API_ID"):
                api_id = line.split(":")[1].strip()
            elif line.startswith("API_HASH"):
                api_hash = line.split(":")[1].strip()

    app = Client(
        os.path.join(session_folder, "KnUser"),
        api_id=api_id,
        api_hash=api_hash
    )

    # Запускаем клиента Pyrogram
    with app:
        print(f"[{time.strftime('%d-%m-%Y %H:%M:%S')}]> Файл сессии загружен: KnUser.session", Fore.GREEN)
        time.sleep(1.5)

        # Добавляем декоратор и обработку сообщений
        @app.on_message()
        def handle_message(client, message):
            print(message)  # Здесь можно добавить обработку сообщений

# Функция для вывода логотипа
def print_logo():
    logo = r"""
_  __        _   _                    _____      ___   _____ 
| |/ / _ __  | | | | ___   ___  _ __  |___ /     / _ \ |___ / 
| ' / | '_ \ | | | |/ __| / _ \| '__|   |_ \    | | | |  |_ \ 
| . \ | | | || |_| |\__ \|  __/| |     ___) | _ | |_| | ___) |
|_|\_\|_| |_| \___/ |___/ \___||_|    |____/ (_) \___/ |____/
    """
    return logo

# Устанавливаем текущую версию
version = "3.03 beta🔥"

# Перед созданием клиента сохраните текущее время
start_time = time.time()

# Выводим логотип и сообщение о готовности бота к работе перед его запуском
print(print_logo())  # Выводим логотип 
time.sleep(1.5)

print(f"{Fore.WHITE}[{time.strftime('%d-%m-%Y %H:%M:%S')}]> {Fore.GREEN}KnUser запущен{Style.RESET_ALL}")
time.sleep(1.5)

print(f"[{time.strftime('%d-%m-%Y %H:%M:%S')}]> {Fore.BLUE}Привет, {socket.gethostname()}{Style.RESET_ALL}")
time.sleep(1.5)

print(f"[{time.strftime('%d-%m-%Y %H:%M:%S')}]> {Fore.BLUE}Текущая версия : {version}{Fore.BLUE}{Style.RESET_ALL}")
time.sleep(1.5)

# Загрузка плагинов из папки "plugins"
plugins_dir = "plugins"

# Получаем список файлов в папке "plugins"
plugin_files = os.listdir(plugins_dir)

# Импортируем и регистрируем каждый плагин
for plugin_file in plugin_files:
    if plugin_file.endswith(".py"):
        plugin_path = os.path.join(plugins_dir, plugin_file)
        plugin_name = os.path.splitext(plugin_file)[0]

        try:
            # Загружаем модуль
            spec = importlib.util.spec_from_file_location(plugin_name, plugin_path)
            plugin_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(plugin_module)

            # Регистрируем плагин (предположим, что в каждом плагине есть функция register)
            plugin_module.register(app)

            # Выводим сообщение о регистрации плагина
            print(f"[{time.strftime('%d-%m-%Y %H:%M:%S')}]> {Fore.BLUE}Плагин {plugin_name} зарегистрирован{Fore.BLUE}{Style.RESET_ALL}")
            time.sleep(0.5)

        except Exception as e:
            # Выводим сообщение о проблеме с плагином
            print(f"Возникла проблема с плагином {plugin_name}: {str(e)}")

# Время запуска бота
start_time = time.time()

# Команда .about
@app.on_message(filters.command("about", prefixes=".") & filters.me)
async def about_command(_, msg):
    # Определяем время последнего запуска
    current_time = time.time()
    last_start_time = current_time - start_time
    last_start_hours = int(last_start_time // 3600)
    last_start_minutes = int((last_start_time % 3600) // 60)
    last_start_seconds = int(last_start_time % 60)

    # Форматируем время для вывода
    last_start_formatted = ""
    if last_start_hours != 0:
        last_start_formatted += f"{last_start_hours} часов "
    if last_start_minutes != 0:
        last_start_formatted += f"{last_start_minutes} минут "
    if last_start_seconds != 0:
        last_start_formatted += f"{last_start_seconds} секунд"
    if last_start_hours == 0 and last_start_minutes == 0 and last_start_seconds == 0:
        last_start_formatted = "меньше секунды"

    about_text = (
        "🔥KnUser:\n"
        f"ℹ️Версия: {version}\n"
        "💻Разработчик: @Demkys\n"
        f"⏳Последний запуск: {last_start_formatted} назад"
    )

    await msg.reply(about_text)

# Команда .reset
@app.on_message(filters.command("reset", prefixes=".") & filters.me)
async def reset_bot(_, msg):
    restart_text = "🔄Перезагружаюсь..\n✨Потребуется некоторое время...."
    await msg.edit(restart_text)

    # Задержка для имитации перезагрузки
    await asyncio.sleep(3)

    # После перезагрузки отправляем уведомление
    await msg.edit("KnUser перезагружен🔄")
    
    # Перезагрузка скрипта
    python = sys.executable
    os.execl(python, python, *sys.argv)
# Запускаем клиент Pyrogram
app.run()