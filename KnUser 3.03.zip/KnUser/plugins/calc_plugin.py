import time
from pyrogram import filters

def register(app):
    @app.on_message(filters.command("calc", prefixes=".") & filters.me)
    async def calculate(_, msg):
        try:
            # Получаем выражение для вычисления из сообщения пользователя
            expression = msg.text.split(".calc ", maxsplit=1)[1]

            # Пытаемся выполнить вычисление
            result = eval(expression)

            # Отправляем результат обратно в чат
            await msg.reply(f"Результат: {result}")
        except Exception as e:
            # Если возникает исключение, выводим сообщение о неверном выражении
            error_message = f"При работе KnUser произошла ошибка: {e}"
            print(error_message)
            await msg.reply(error_message)
