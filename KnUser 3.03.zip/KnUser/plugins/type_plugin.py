import asyncio
from pyrogram import filters
from pyrogram.errors import FloodWait

def register(app):
    @app.on_message(filters.command("type", prefixes=".") & filters.me)
    async def type_command(_, msg):
        orig_text = msg.text.split(".type ", maxsplit=1)[1]
        tbp = ""  # то, что будет напечатано
        typing_symbol = "▒"

        for character in orig_text:
            try:
                # Добавляем символ к тексту, который будет напечатан
                tbp += character
                # Отображаем в чате символы, которые будут напечатаны
                await msg.edit(tbp + typing_symbol)
                # Ожидаем некоторое время, чтобы имитировать набор
                await asyncio.sleep(0.50)  # 50 миллисекунд

            except FloodWait as e:
                # Обрабатываем случаи ожидания (если Telegram требует задержки)
                await asyncio.sleep(e.x)

        # После завершения набора удаляем символ набора
        await msg.edit(orig_text)
