from pyrogram import filters

def register(app):
    @app.on_message(filters.command("del", prefixes=".") & filters.me)
    async def delete_message(_, msg):
        # Проверяем, есть ли сообщение, на которое мы можем ответить
        if msg.reply_to_message:
            await msg.reply_to_message.delete()  # Удаляем сообщение, на которое мы ответили
            await msg.delete()  # Удаляем само сообщение с командой .del
