import asyncio
from pyrogram import filters
import wikipedia
import time

def register(app):
    @app.on_message(filters.command("wiki", prefixes=".") & filters.me)
    async def wiki(_, msg):
        try:
            # Извлечение запроса из сообщения
            query = msg.text.split(".wiki ", maxsplit=1)[1]
            # Установка русского языка для Wikipedia
            wikipedia.set_lang("ru")
            
            # Попытка получить информацию из Wikipedia
            result = wikipedia.summary(query)
            await msg.edit(result)

        except wikipedia.exceptions.DisambiguationError as e:
            # Обработка случая неоднозначности запроса
            options = "\n".join(e.options)
            await msg.reply(f"Уточните запрос, возможно вы имели в виду:\n{options}", quote=True)

        except wikipedia.exceptions.PageError:
            # Обработка случая отсутствия страницы на Wikipedia
            await msg.reply(f"Запрос '{query}' не найден на Википедии.", quote=True)

        except Exception as e:
            # Общая обработка ошибок
            error_message = f"[{time.strftime('%d-%m-%Y %H:%M:%S')}]> ❌ При работе KnUser произошла ошибка: {e}"
            print(error_message)