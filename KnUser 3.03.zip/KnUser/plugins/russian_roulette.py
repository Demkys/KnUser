import random
from pyrogram import filters

chamber = [0, 0, 0, 0, 0, 1]
random.shuffle(chamber)  # Перемешиваем патроны
current_chamber = 0  # Текущая камера

def register(app):
    @app.on_message(filters.command("rull", prefixes=".") & filters.me)
    async def roulette(_, msg):
        global current_chamber

        if chamber[current_chamber] == 1:
            await msg.reply("💥 Бах! Вы проиграли.")
            # Перезапускаем игру
            random.shuffle(chamber)
            current_chamber = 0
        else:
            # Увеличиваем номер камеры, если она не последняя
            if current_chamber < len(chamber) - 1:
                current_chamber += 1
                await msg.reply("🔫 Щелчок. Вы выжили. Играем дальше?")
            else:
                # Если это последняя камера, спрашиваем пользователя, хочет ли он продолжить игру
                await msg.reply("🔫 Щелчок. Вы выжили. Хотите сыграть еще раз?")
