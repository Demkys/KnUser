import time
from pyrogram import filters

def register(app):
    @app.on_message(filters.command("ping", prefixes=".") & filters.me)
    async def ping_pong(_, msg):
        # Запоминаем время отправки сообщения
        start_time = time.time()
        # Отправляем сообщение "Pong"
        sent_message = await msg.reply("Pong!")
        # Вычисляем время задержки
        end_time = time.time()
        ping_duration = end_time - start_time
        # Редактируем сообщение, добавляя время задержки
        await sent_message.edit(f"Pong! Задержка: {ping_duration:.2f} секунд")
