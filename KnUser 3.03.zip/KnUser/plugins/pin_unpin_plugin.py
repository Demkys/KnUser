from pyrogram import filters

def register(app):
    # Команда .pin
    @app.on_message(filters.command("pin", prefixes=".") & filters.me)
    async def pin_message(_, msg):
        if msg.reply_to_message:
            # Закрепляем сообщение
            await msg.reply_to_message.pin()
            await msg.delete()

    # Команда .unpin
    @app.on_message(filters.command("unpin", prefixes=".") & filters.me)
    async def unpin_message(_, msg):
        if msg.reply_to_message:
            # Открепляем сообщение, если оно было закреплено
            await msg.reply_to_message.unpin()
            await msg.delete()
