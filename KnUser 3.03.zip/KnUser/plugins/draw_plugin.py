import time
from pyrogram import filters
from art import text2art
from colorama import Fore, Style

def register(app):
    @app.on_message(filters.command("draw", prefixes=".") & filters.me)
    async def draw(_, msg):
        try:
            # Получаем текст для рисования из сообщения пользователя
            text = msg.text.split(".draw ", maxsplit=1)[1]

            # Генерируем ASCII-арт
            ascii_art = text2art(text)

            # Отправляем ASCII-арт в чат
            await msg.reply(f"```\n{ascii_art}\n```")
        except Exception as e:
            error_message = f"[{time.strftime('%d-%m-%Y %H:%M:%S')}]> ❌ {Fore.RED}При работе KnUser произошла ошибка: {e}"
            print(error_message)
            await msg.reply(error_message)
